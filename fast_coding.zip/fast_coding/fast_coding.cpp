/*
  fast_coding.cpp - Library for flashing fast_coding code.
  Created by arutsch, january 24, 2021.
  Released into the public domain.
*/

#include "Arduino.h"
#include "fast_coding.h"

fast_coding::fast_coding(int pin)
{
  pinMode(pin, OUTPUT);
  _pin = pin;
}

void fast_coding::OU()
{
    pinMode(_pin, OUTPUT);
}

void fast_coding::IN()
{
   pinMode(_pin, INPUT); 
}

void fast_coding::HI()
{
    digitalWrite(_pin, HIGH);
}

void fast_coding::LO()
{
  digitalWrite(_pin, LOW);  
}

void inc1(data1)
{
 #include data1
 }

void inc2(data1, data2)
{
  #include data1
  #include data2
}

void inc3(data1, data2, data3)
{
 #include data1
  #include data2
  #include data3
}

void inc4(data1, data2, data3, data4)
{
  #include data1
  #include data2
  #include data3
  #include data4
}

void inc5(data1, data2, data3, data4, data5)
{
  #include data1
  #include data2
  #include data3
  #include data4
  #include data5
}

void inc6(data1, data2, data3, data4, data5, data6)
{
 #include data1
  #include data2
  #include data3
  #include data4
  #include data5
  #include data6
}
