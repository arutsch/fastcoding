/*
  fast_coding.h - Library for flashing fast_coding code.
  Created by arutsch, january 24, 2021.
  Released into the public domain.
*/
#ifndef fast_coding_h
#define fast_coding_h

#define data1 
#define data2
#define data3
#define data4
#define data5
#define data6

#include "Arduino.h"

class fast_coding
{
    public:
    fast_coding(int pin);
    void OU();
    void IN();
    void HI();
    void LO();
    void inc1(data1);
    void inc2(data1, data2);
    void inc3(data1, data2, data3);
    void inc4(data1, data2, data3, data4);
    void inc5(data1, data2, data3, data4, data5);
    void inc6(data1, data2, data3, data4, data5, data6);

  private:
    int _pin;
};

#endif

